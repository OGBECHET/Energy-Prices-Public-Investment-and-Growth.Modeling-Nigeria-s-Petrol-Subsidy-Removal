source("rck_nigeria_fiscal.R")
cols <- c(Leak = "#B2182B", Transfers = "#E08214", Invest = "#2166AC")
lab  <- c(Leak = "Leak (savings lost)", Transfers = "Cash transfers", Invest = "Public investment")
yrs  <- res$Leak$t <= 60
pct  <- function(x, ref) 100 * (x / ref - 1)
panel <- function(var, ref, title, leg = FALSE) {
  ys <- lapply(res, function(r) pct(r[[var]][yrs], ref))
  plot(NA, xlim = c(0, 60), ylim = range(unlist(ys), 0), xlab = "Years after reform",
       ylab = "% change from pre-reform", main = title, las = 1, bty = "l")
  abline(h = 0, col = "grey60", lty = 2)
  for (s in c("Leak","Transfers","Invest")) lines(res[[s]]$t[yrs], ys[[s]], col = cols[s], lwd = 2.2,
                                               lty = if (s == "Transfers") 2 else 1)
  if (leg) legend("topleft", lab, col = cols, lwd = 2.2, lty = c(1,2,1), bty = "n", cex = 0.85)
}
pdf("figures/fig_paths.pdf", width = 7.5, height = 6, family = "Times")
par(mfrow = c(2, 2), mar = c(4, 4.3, 2, 0.8), cex.main = 1, mgp = c(2.6, 0.7, 0))
panel("c",  base$c0,  "(a) Consumption", leg = TRUE)
panel("V",  base$V0,  "(b) Output (GDP)")
panel("k",  base$k0,  "(c) Private capital")
panel("kg", base$kg0, "(d) Public capital")
dev.off()

w <- c(Invest_full = rob$welfare_Invest[rob$eps_new==1 & rob$delta_g==0.0375],
       Invest_half = rob$welfare_Invest[rob$eps_new==0.5 & rob$delta_g==0.0375],
       Transfers = tab$welfare_pct[2], Leak = tab$welfare_pct[1])
pdf("figures/fig_welfare.pdf", width = 6.5, height = 3.6, family = "Times")
par(mar = c(3, 4.5, 1, 1), mgp = c(2.8, 0.7, 0))
bp <- barplot(w, col = c(cols["Invest"], adjustcolor(cols["Invest"], 0.45), cols["Transfers"], cols["Leak"]),
   border = NA, ylim = c(-2, 2.7), las = 1, ylab = "Welfare gain (% of consumption)",
   names.arg = c("Public investment\n(full efficiency)", "Public investment\n(half efficiency)",
                 "Cash transfers", "Leak"), cex.names = 0.85, mgp = c(2.8, 1.6, 0))
abline(h = 0)
text(bp, w, sprintf("%+.2f", w), pos = ifelse(w > 0, 3, 1), cex = 0.9)
dev.off()

eig <- t(sapply(res, function(r) sort(Re(r$eig))))
write.csv(round(eig, 4), "results/eigenvalues.csv")
print(round(eig,4)); print(tab); print(rob)
